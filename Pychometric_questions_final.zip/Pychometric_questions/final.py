from flask import Flask, render_template, session, request, redirect, url_for
import random
import pandas as pd
from flask_session import Session
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'

app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_FILE_DIR'] = './flask_sessions'

Session(app)

# Database setup
def init_db():
    conn = sqlite3.connect('quiz.db')
    c = conn.cursor()
    # Users table with gender added
    c.execute('''CREATE TABLE IF NOT EXISTS users 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT NOT NULL,
                  age INTEGER NOT NULL,
                  phone TEXT NOT NULL,
                  gender TEXT NOT NULL)''')
    # Answers table (unchanged)
    c.execute('''CREATE TABLE IF NOT EXISTS answers 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  question TEXT NOT NULL,
                  answer TEXT NOT NULL,
                  FOREIGN KEY (user_id) REFERENCES users(id))''')
    # Results table like main.py
    c.execute('''CREATE TABLE IF NOT EXISTS results 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  phase1_tech_count INTEGER,
                  phase1_non_tech_count INTEGER,
                  phase2_category TEXT,
                  phase3_subcategory TEXT,
                  final_result TEXT,
                  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (user_id) REFERENCES users(id))''')
    conn.commit()
    conn.close()

# Load questions from Excel
def load_questions_from_excel(file_path, num_questions, exclude_questions=None):
    df = pd.read_excel(file_path)
    question_list = []
    for _, row in df.iterrows():
        options = [row[f"option_{i}"] for i in range(1, 7) if pd.notna(row.get(f"option_{i}"))]
        options_disc = [row[f"option_{i}_disc"] for i in range(1, 7) if pd.notna(row.get(f"option_{i}_disc"))]
        question_dict = {
            "question": row["question"],
            "options": options,
            "options_disc": options_disc
        }
        question_list.append(question_dict)
    if exclude_questions:
        question_list = [q for q in question_list if q["question"] not in [eq["question"] for eq in exclude_questions]]
    return random.sample(question_list, min(num_questions, len(question_list)))

# Result messages (unchanged from your final.py)
result_messages = {
    "I": {"full_form": "<b>Industry 4.0/Automation</b>", "message": "You're destined to lead the future of smart manufacturing!"},
    "R": {"full_form": "<b>Robotics</b>", "message": "Get ready to build the future, one robot at a time!"},
    "M": {"full_form": "<b>Mechatronics</b>", "message": "You’re a master of machines and electronics!"},
    "FD": {"full_form": "<b>Frontend Development</b>", "message": "Crafting stunning web experiences is your calling!"},
    "DB": {"full_form": "<b>Backend Development</b>", "message": "You’re the backbone of data-driven solutions!"},
    "AM": {"full_form": "<b>Additive Manufacturing (3D Printing)</b>", "message": "Bring stories to life with your imagination!"},
    "PM": {"full_form": "<b>Precision Manufacturing</b>", "message": "You’re a visionary leader!"},
    "CNC": {"full_form": "<b>CNC Programming</b>", "message": "Precision is your superpower!"},
    "WT": {"full_form": "<b>Welding Technician</b>", "message": "The digital world is yours to conquer!"},
    "aiml": {"full_form": "<b>Artificial Intelligence and Machine Learning</b>", "message": "You’re set to unlock the power of smart machines!"},
    "ds": {"full_form": "<b>Data Science</b>", "message": "Turn data into gold!"},
    "cs": {"full_form": "<b>Cybersecurity</b>", "message": "Protect the digital realm like a pro!"},
    "cc": {"full_form": "<b>Cloud Computing</b>", "message": "Soar above the clouds with your tech prowess!"},
    "iot": {"full_form": "<b>Internet of Things</b>", "message": "Connect the world, one device at a time!"},
    "A_H": {"full_form": "<b>Arts and Humanities</b>", "message": "Your creativity will shape culture and inspire others!"},
    "B_C": {"full_form": "<b>Business and Commerce</b>", "message": "You’re destined to lead in the world of trade and innovation!"},
    "S_S": {"full_form": "<b>Social Sciences</b>", "message": "Understanding society is your strength—change the world with your insights!"},
    "E_T": {"full_form": "<b>Education and Teaching</b>", "message": "Empower the next generation with your passion for teaching!"},
    "S_F": {"full_form": "<b>Sports and Fitness</b>", "message": "Your energy will drive success in sports and wellness!"},
    "F_D": {"full_form": "<b>Fashion and Design</b>", "message": "Style is your superpower—create trends that captivate the world!"},
    "L_T": {"full_form": "<b>Literature & Journalism</b>", "message": "Your words will inform, entertain, and inspire the world!"},
    "P": {"full_form": "<b>Psychology</b>", "message": "You’ll unlock the secrets of the mind and help others thrive!"},
    "Law": {"full_form": "<b>Law</b>", "message": "Justice is your calling—shape the world with your legal expertise!"},
    "H_A": {"full_form": "<b>History & Archaeology</b>", "message": "You’ll uncover the past to enlighten the future!"},
    "Philosophy": {"full_form": "<b>Philosophy</b>", "message": "Your deep thoughts will challenge and redefine perspectives!"},
    "Manag": {"full_form": "<b>Management</b>", "message": "You’re a natural leader ready to guide teams to success!"},
    "F_A": {"full_form": "<b>Finance & Accounting</b>", "message": "You’ll master the art of numbers and financial strategy!"},
    "E": {"full_form": "<b>Entrepreneurship</b>", "message": "You’ll build innovative ventures from the ground up!"},
    "MKT": {"full_form": "<b>Marketing</b>", "message": "You’ll captivate audiences with your creative campaigns!"},
    "S_R": {"full_form": "<b>Sales & Retail Management</b>", "message": "Your charisma will drive sales and customer loyalty!"},
    "Teaching": {"full_form": "<b>Teaching</b>", "message": "You’ll inspire and shape the minds of tomorrow!"},
    "SE": {"full_form": "<b>Adaptive Education Teacher</b>", "message": "You’ll empower unique learners to reach their potential!"},
    "Educational_C": {"full_form": "<b>Educational Counseling</b>", "message": "You’ll guide students toward their brightest futures!"},
    "Sports_Management": {"full_form": "<b>Sports Management</b>", "message": "You’ll lead the business of sports to new heights!"},
    "Fitness_Training": {"full_form": "<b>Fitness Training</b>", "message": "You’ll transform lives through health and fitness!"},
    "Coaching": {"full_form": "<b>Coaching</b>", "message": "You’ll motivate athletes to achieve greatness!"},
    "Fashion_Designing": {"full_form": "<b>Fashion Designing</b>", "message": "You’ll set trends with your stunning designs!"},
    "Interior_Design": {"full_form": "<b>Interior Design</b>", "message": "You’ll create beautiful and functional spaces!"},
    "Graphic_Design": {"full_form": "<b>Graphic Design</b>", "message": "Your visual creativity will captivate audiences!"},
    "Social_Work": {"full_form": "<b>Social Work</b>", "message": "You’ll uplift lives and strengthen communities!"},
    "Public_Administration": {"full_form": "<b>Public Administration</b>", "message": "You’ll shape policies for the greater good!"},
    "Community_Development": {"full_form": "<b>Community Development</b>", "message": "You’ll build thriving, connected communities!"}
}

# Home page (index.html)
@app.route('/')
def index():
    return render_template('index.html')

# Video page
@app.route('/video')
def video():
    return render_template('video.html')

# Login page (updated to include gender)
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        name = request.form.get('name')
        age = request.form.get('age')
        phone = request.form.get('phone')
        gender = request.form.get('gender')
        
        if not name or not age or not phone or not gender:
            return render_template('login.html', error="Please fill in all fields.")
        
        try:
            age = int(age)
            conn = sqlite3.connect('quiz.db')
            c = conn.cursor()
            c.execute("INSERT INTO users (name, age, phone, gender) VALUES (?, ?, ?, ?)", (name, age, phone, gender))
            user_id = c.lastrowid
            conn.commit()
            conn.close()
            session['user_id'] = user_id
            return redirect(url_for('quiz'))
        except ValueError:
            return render_template('login.html', error="Age must be a number.")
        except sqlite3.Error:
            return render_template('login.html', error="An error occurred. Please try again.")
    
    return render_template('login.html')

# Quiz logic (unchanged until result saving)
@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if 'phase' not in session:
        session['phase'] = 1
        session['questions'] = load_questions_from_excel("first_1.xlsx", 5)
        session['current_question'] = 0
        session['tech_count'] = 0
        session['non_tech_count'] = 0
        session['answers'] = []

    if request.method == 'POST':
        choice = request.form.get('choice')
        user_id = session['user_id']
        
        current_q = session['questions'][session['current_question']]
        session['answers'].append({"question": current_q["question"], "answer": choice})

        if session['phase'] == 1:
            if choice in current_q['options_disc']:
                if choice == 'tech':
                    session['tech_count'] += 1
                elif choice == 'non-tech':
                    session['non_tech_count'] += 1
            session['current_question'] += 1
            session.modified = True

        elif session['phase'] == 2:
            total_questions = session.get('phase_2_total_questions', 7)
            current_q = session['questions'][session['current_question']]

            if 'is_tech' in session and session['is_tech']:
                if session['current_question'] < 7:
                    if choice in session['category_counts']:
                        session['category_counts'][choice] += 1
                    session['current_question'] += 1

                elif session['current_question'] == 7:
                    if choice in session['category_counts']:
                        session['highest_category'] = choice
                        session['phase'] = 3
                        session['current_question'] = 0

                        session['aiml_ds_counts'] = {"aiml": 0, "ds": 0}
                        session['industry_counts'] = {"I": 0, "R": 0, "M": 0}
                        session['web_counts'] = {"FD": 0, "DB": 0}
                        session['design_counts'] = {"AM": 0, "PM": 0, "CNC": 0, "WT": 0}
                        if choice == "cloud":
                            session['aiml_ds_counts'] = {"cs": 0, "cc": 0}

                        category_questions = {
                            "ai": load_questions_from_excel("ai.xlsx", 3),
                            "iot": load_questions_from_excel("iot.xlsx", 2),
                            "cloud": load_questions_from_excel("cloud.xlsx", 3),
                            "industry": load_questions_from_excel("industry.xlsx", 4),
                            "design": load_questions_from_excel("design.xlsx", 5),
                            "web": load_questions_from_excel("web.xlsx", 3)
                        }
                        session['questions'] = category_questions.get(choice, [])
                        return redirect('/quiz')

                if session['current_question'] == 7 and 'highest_category' not in session:
                    counts = session['category_counts']
                    max_count = max(counts.values())
                    tied_categories = [cat for cat, count in counts.items() if count == max_count]

                    if len(tied_categories) > 1:
                        extra_questions = load_questions_from_excel("technical_1.xlsx", 1)
                        session['questions'].extend(extra_questions)
                        session['phase_2_total_questions'] = 8
                        return redirect('/quiz')
                    else:
                        highest_category = max(counts, key=counts.get)
                        session['highest_category'] = highest_category
                        session['phase'] = 3
                        session['current_question'] = 0

                        session['aiml_ds_counts'] = {"aiml": 0, "ds": 0}
                        session['industry_counts'] = {"I": 0, "R": 0, "M": 0}
                        session['web_counts'] = {"FD": 0, "DB": 0}
                        session['design_counts'] = {"AM": 0, "PM": 0, "CNC": 0, "WT": 0}
                        if highest_category == "cloud":
                            session['aiml_ds_counts'] = {"cs": 0, "cc": 0}

                        category_questions = {
                            "ai": load_questions_from_excel("ai.xlsx", 3),
                            "iot": load_questions_from_excel("iot.xlsx", 2),
                            "cloud": load_questions_from_excel("cloud.xlsx", 3),
                            "industry": load_questions_from_excel("industry.xlsx", 4),
                            "design": load_questions_from_excel("design.xlsx", 5),
                            "web": load_questions_from_excel("web.xlsx", 3)
                        }
                        session['questions'] = category_questions.get(highest_category, [])
                        return redirect('/quiz')

            else:  # Non-technical path
                if session['current_question'] < 7:
                    if choice in session['category_counts']:
                        session['category_counts'][choice] += 1
                    session['current_question'] += 1

                elif session['current_question'] == 7:
                    if choice in session['category_counts']:
                        session['highest_category'] = choice
                        if choice in ['A_H', 'B_C', 'E_T', 'S_F', 'F_D', 'S_S']:
                            session['phase'] = 3
                            session['current_question'] = 0
                            category_files = {
                                'A_H': ("arts.xlsx", {"L_T": 0, "P": 0, "Law": 0, "H_A": 0, "Philosophy": 0}, 3),
                                'B_C': ("business.xlsx", {"Manag": 0, "F_A": 0, "E": 0, "MKT": 0, "S_R": 0}, 3),
                                'E_T': ("teaching.xlsx", {"Teaching": 0, "SE": 0, "Educational_C": 0}, 3),
                                'S_F': ("sports.xlsx", {"Sports_Management": 0, "Fitness_Training": 0, "Coaching": 0}, 3),
                                'F_D': ("fashion.xlsx", {"Fashion_Designing": 0, "Interior_Design": 0, "Graphic_Design": 0}, 3),
                                'S_S': ("services.xlsx", {"Social_Work": 0, "Public_Administration": 0, "Community_Development": 0}, 3)
                            }
                            file, counts, num = category_files[choice]
                            session['questions'] = load_questions_from_excel(file, num)
                            session['category_counts'] = counts
                            session['initial_phase_3_questions'] = num
                            return redirect('/quiz')
                        else:
                            message = f"You are most suited for {result_messages[choice]['full_form']}! {result_messages[choice]['message']}"
                            session['final_result'] = message
                            return redirect('/save_result')

                if session['current_question'] == 7 and 'highest_category' not in session:
                    counts = session['category_counts']
                    max_count = max(counts.values())
                    tied_categories = [cat for cat, count in counts.items() if count == max_count]

                    if len(tied_categories) > 1:
                        extra_questions = load_questions_from_excel("non_tech.xlsx", 1)
                        session['questions'].extend(extra_questions)
                        session['phase_2_total_questions'] = 8
                        return redirect('/quiz')
                    else:
                        highest_category = max(counts, key=counts.get)
                        session['highest_category'] = highest_category
                        if highest_category in ['A_H', 'B_C', 'E_T', 'S_F', 'F_D', 'S_S']:
                            session['phase'] = 3
                            session['current_question'] = 0
                            category_files = {
                                'A_H': ("arts.xlsx", {"L_T": 0, "P": 0, "Law": 0, "H_A": 0, "Philosophy": 0}, 3),
                                'B_C': ("business.xlsx", {"Manag": 0, "F_A": 0, "E": 0, "MKT": 0, "S_R": 0}, 3),
                                'E_T': ("teaching.xlsx", {"Teaching": 0, "SE": 0, "Educational_C": 0}, 3),
                                'S_F': ("sports.xlsx", {"Sports_Management": 0, "Fitness_Training": 0, "Coaching": 0}, 3),
                                'F_D': ("fashion.xlsx", {"Fashion_Designing": 0, "Interior_Design": 0, "Graphic_Design": 0}, 3),
                                'S_S': ("services.xlsx", {"Social_Work": 0, "Public_Administration": 0, "Community_Development": 0}, 3)
                            }
                            file, counts, num = category_files[highest_category]
                            session['questions'] = load_questions_from_excel(file, num)
                            session['category_counts'] = counts
                            session['initial_phase_3_questions'] = num
                            return redirect('/quiz')
                        else:
                            message = f"You are most suited for {result_messages[highest_category]['full_form']}! {result_messages[highest_category]['message']}"
                            session['final_result'] = message
                            return redirect('/save_result')

            session.modified = True

        elif session['phase'] == 3:
            highest_category = session.get('highest_category')
            total_questions = len(session['questions'])
            current_q = session['questions'][session['current_question']]

            if highest_category == "A_H" and choice in ["L_T", "P", "Law", "H_A", "Philosophy"]:
                session['category_counts'][choice] += 1
            elif highest_category == "B_C" and choice in ["Manag", "F_A", "E", "MKT", "S_R"]:
                session['category_counts'][choice] += 1
            elif highest_category == "E_T" and choice in ["Teaching", "SE", "Educational_C"]:
                session['category_counts'][choice] += 1
            elif highest_category == "S_F" and choice in ["Sports_Management", "Fitness_Training", "Coaching"]:
                session['category_counts'][choice] += 1
            elif highest_category == "F_D" and choice in ["Fashion_Designing", "Interior_Design", "Graphic_Design"]:
                session['category_counts'][choice] += 1
            elif highest_category == "S_S" and choice in ["Social_Work", "Public_Administration", "Community_Development"]:
                session['category_counts'][choice] += 1
            elif highest_category == "industry" and choice in ["I", "R", "M"]:
                session['industry_counts'][choice] += 1
            elif highest_category == "web" and choice in ["FD", "DB"]:
                session['web_counts'][choice] += 1
            elif highest_category == "design" and choice in ["AM", "PM", "CNC", "WT"]:
                session['design_counts'][choice] += 1
            elif highest_category in ["ai", "iot"] and choice in ["aiml", "ds"]:
                session['aiml_ds_counts'][choice] += 1
            elif highest_category == "cloud" and choice in ["cc", "cs"]:
                session['aiml_ds_counts'][choice] += 1

            session['current_question'] += 1
            session.modified = True

    # Phase transitions and rendering logic
    if session['phase'] == 1:
        if session['current_question'] < len(session['questions']):
            question = session['questions'][session['current_question']]
            return render_template("quiz.html", question=question, phase=session['phase'])
        else:
            session['phase'] = 2
            session['current_question'] = 0
            if session['tech_count'] > session['non_tech_count']:
                session['questions'] = load_questions_from_excel("technical_1.xlsx", 7)
                session['category_counts'] = {"ai": 0, "iot": 0, "cloud": 0, "industry": 0, "design": 0, "web": 0}
                session['is_tech'] = True
            else:
                session['questions'] = load_questions_from_excel("non_tech.xlsx", 7)
                session['category_counts'] = {"A_H": 0, "B_C": 0, "S_S": 0, "E_T": 0, "S_F": 0, "F_D": 0}
                session['is_tech'] = False
            session['phase_2_total_questions'] = 7
            session.modified = True
            return redirect('/quiz')

    elif session['phase'] == 2:
        total_questions = session.get('phase_2_total_questions', 7)
        if session['current_question'] < total_questions:
            question = session['questions'][session['current_question']]
            return render_template("quiz.html", question=question, phase=session['phase'])
        else:
            if 'is_tech' in session and session['is_tech']:
                return redirect('/quiz')
            else:
                counts = session['category_counts']
                max_count = max(counts.values())
                tied_categories = [cat for cat, count in counts.items() if count == max_count]
                highest_category = session.get('highest_category', max(counts, key=counts.get))
                if highest_category in ['A_H', 'B_C', 'E_T', 'S_F', 'F_D', 'S_S']:
                    session['phase'] = 3
                    session['current_question'] = 0
                    category_files = {
                        'A_H': ("arts.xlsx", {"L_T": 0, "P": 0, "Law": 0, "H_A": 0, "Philosophy": 0}, 3),
                        'B_C': ("business.xlsx", {"Manag": 0, "F_A": 0, "E": 0, "MKT": 0, "S_R": 0}, 3),
                        'E_T': ("teaching.xlsx", {"Teaching": 0, "SE": 0, "Educational_C": 0}, 3),
                        'S_F': ("sports.xlsx", {"Sports_Management": 0, "Fitness_Training": 0, "Coaching": 0}, 3),
                        'F_D': ("fashion.xlsx", {"Fashion_Designing": 0, "Interior_Design": 0, "Graphic_Design": 0}, 3),
                        'S_S': ("services.xlsx", {"Social_Work": 0, "Public_Administration": 0, "Community_Development": 0}, 3)
                    }
                    file, counts, num = category_files[highest_category]
                    session['questions'] = load_questions_from_excel(file, num)
                    session['category_counts'] = counts
                    session['initial_phase_3_questions'] = num
                    session.modified = True
                    return redirect('/quiz')
                else:
                    message = f"You are most suited for {result_messages[highest_category]['full_form']}! {result_messages[highest_category]['message']}"
                    session['final_result'] = message
                    return redirect('/save_result')

    elif session['phase'] == 3:
        total_questions = len(session['questions'])
        if session['current_question'] < total_questions:
            question = session['questions'][session['current_question']]
            return render_template("quiz.html", question=question, phase=session['phase'])
        else:
            highest_category = session.get('highest_category')
            if highest_category == "iot":
                result = result_messages["iot"]
                message = f"You are most suited for {result['full_form']}! {result['message']}"
                session['final_result'] = message
                return redirect('/save_result')
            elif highest_category in ["A_H", "B_C", "E_T", "S_F", "F_D", "S_S"]:
                initial_questions = session.get('initial_phase_3_questions', 3)
                if session['current_question'] == initial_questions:
                    counts = session['category_counts']
                    max_count = max(counts.values())
                    tied_categories = [cat for cat, count in counts.items() if count == max_count]

                    if len(tied_categories) > 1:
                        file_map = {
                            "A_H": "arts.xlsx",
                            "B_C": "business.xlsx",
                            "E_T": "teaching.xlsx",
                            "S_F": "sports.xlsx",
                            "F_D": "fashion.xlsx",
                            "S_S": "services.xlsx"
                        }
                        extra_questions = load_questions_from_excel(file_map[highest_category], 1, exclude_questions=session['questions'])
                        if not extra_questions:
                            extra_questions = random.sample(session['questions'], 1)
                        session['questions'].extend(extra_questions)
                        session.modified = True
                        return redirect('/quiz')
                    else:
                        highest_subcategory = max(counts, key=counts.get)
                        result = result_messages.get(highest_subcategory, {"full_form": highest_subcategory.replace('_', ' ').title(),
                                                                          "message": "Your skills will shape the future!"})
                        message = f"You are most suited for {result['full_form']}! {result['message']}"
                        session['final_result'] = message
                        return redirect('/save_result')
                else:  # After tiebreaker question
                    last_q = session['questions'][session['current_question'] - 1]
                    highest_subcategory = next((disc for i, disc in enumerate(last_q['options_disc']) if disc == choice), 
                                               max(session['category_counts'], key=session['category_counts'].get))
                    result = result_messages.get(highest_subcategory, {"full_form": highest_subcategory.replace('_', ' ').title(),
                                                                      "message": "Your skills will shape the future!"})
                    message = f"You are most suited for {result['full_form']}! {result['message']}"
                    session['final_result'] = message
                    return redirect('/save_result')
            else:
                if highest_category == "industry":
                    highest_subcategory = max(session['industry_counts'], key=session['industry_counts'].get)
                elif highest_category == "web":
                    highest_subcategory = max(session['web_counts'], key=session['web_counts'].get)
                elif highest_category == "design":
                    highest_subcategory = max(session['design_counts'], key=session['design_counts'].get)
                elif highest_category == "cloud":
                    highest_subcategory = max(session['aiml_ds_counts'], key=session['aiml_ds_counts'].get)
                else:
                    highest_subcategory = max(session['aiml_ds_counts'], key=session['aiml_ds_counts'].get)
                result = result_messages.get(highest_subcategory, {"full_form": highest_subcategory.upper(),
                                                                   "message": "Great choice! You're on your way to an exciting tech career!"})
                message = f"You are most suited for {result['full_form']}! {result['message']}"
                session['final_result'] = message
                return redirect('/save_result')

    return redirect('/quiz')

# Save result to database
@app.route('/save_result', methods=['GET', 'POST'])
def save_result():
    user_id = session.get('user_id')
    final_result = session.get('final_result')
    highest_category = session.get('highest_category', '')
    highest_subcategory = None

    # Determine the subcategory based on the final result
    for key, value in result_messages.items():
        if value['full_form'] in final_result:
            highest_subcategory = key
            break

    # Save answers to database
    conn = sqlite3.connect('quiz.db')
    c = conn.cursor()
    for ans in session['answers']:
        c.execute("INSERT INTO answers (user_id, question, answer) VALUES (?, ?, ?)",
                  (user_id, ans['question'], ans['answer']))

    # Save results to database
    c.execute('''INSERT INTO results (user_id, phase1_tech_count, phase1_non_tech_count, phase2_category, phase3_subcategory, final_result)
                 VALUES (?, ?, ?, ?, ?, ?)''',
              (user_id, session.get('tech_count', 0), session.get('non_tech_count', 0),
               highest_category, highest_subcategory, final_result))
    conn.commit()
    conn.close()

    # Clear session after saving
    session.clear()
    return render_template("result.html", message=final_result)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)