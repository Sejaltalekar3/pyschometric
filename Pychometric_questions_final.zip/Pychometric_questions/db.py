from flask import Flask, render_template, session, request, redirect
import random
import pandas as pd
from flask_session import Session

app = Flask(__name__)
app.secret_key = 'your_secret_key'

app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_FILE_DIR'] = './flask_sessions'

Session(app)

questions = [
    {"question": "If you had to choose a summer activity, what would it be?",
     "option_1": "Learning coding, electronics, or working on science experiments.",
     "option_2": "Exploring literature, writing, or participating in theater/drama",
     "option_1_disc": "tech",
     "option_2_disc": "non-tech"},
    {"question": "Imagine you are part of a team solving a big challenge. What role would you prefer?",
     "option_1": "Designing and building a solution using technology",
     "option_2": "Communicating ideas, writing reports, or creating awareness",
     "option_1_disc": "tech",
     "option_2_disc": "non-tech"},
    {"question": "If you were to present something in a competition, what would it be?",
     "option_1": "A science experiment, coding project, or engineering model",
     "option_2": "A debate, artwork, or a documentary film.",
     "option_1_disc": "tech",
     "option_2_disc": "non-tech"},
    {"question": "What excites you more?",
     "option_1": "Experimenting with machines, software, or logical problem-solving",
     "option_2": "Expressing ideas through writing, discussions, or creative work.",
     "option_1_disc": "tech",
     "option_2_disc": "non-tech"},
    {"question": "Which of these school subjects do you enjoy the most?",
     "option_1": "Math, Science, Coding, or Robotics.",
     "option_2": "Literature, Social Studies, Psychology, or Art",
     "option_1_disc": "tech",
     "option_2_disc": "non-tech"}
]

def load_questions_from_excel(file_path, num_questions, exclude_questions=None):
    print(f"Attempting to load questions from {file_path}")
    df = pd.read_excel(file_path)
    print(f"Loaded {len(df)} rows from {file_path}")
    question_list = []
    for _, row in df.iterrows():
        question_dict = {
            "question": row["question"],
            "options": [row[f"option_{i}"] for i in range(1, 7) if pd.notna(row.get(f"option_{i}"))],
            "options_disc": [row[f"option_{i}_disc"] for i in range(1, 7) if pd.notna(row.get(f"option_{i}_disc"))]
        }
        question_list.append(question_dict)
    if exclude_questions:
        question_list = [q for q in question_list if q["question"] not in [eq["question"] for eq in exclude_questions]]
    sampled_questions = random.sample(question_list, min(num_questions, len(question_list)))
    print(f"Sampled {len(sampled_questions)} questions from {file_path}")
    return sampled_questions

result_messages = {
    "I": {"full_form": "Industry 4.0/Automation", "message": "You're destined to lead the future of smart manufacturing!"},
    "R": {"full_form": "Robotics", "message": "Get ready to build the future, one robot at a time!"},
    "M": {"full_form": "Mechatronics", "message": "You’re a master of machines and electronics!"},
    "FD": {"full_form": "Frontend Development", "message": "Crafting stunning web experiences is your calling!"},
    "DB": {"full_form": "Backend Development", "message": "You’re the backbone of data-driven solutions!"},
    "AM": {"full_form": "Additive Manufacturing (3D Printing)", "message": "Bring stories to life with your imagination!"},
    "PM": {"full_form": "Precision Manufacturing", "message": "You’re a visionary leader!"},
    "CNC": {"full_form": "CNC Programming", "message": "Precision is your superpower!"},
    "WT": {"full_form": "Welding Technician", "message": "The digital world is yours to conquer!"},
    "aiml": {"full_form": "Artificial Intelligence and Machine Learning", "message": "You’re set to unlock the power of smart machines!"},
    "ds": {"full_form": "Data Science", "message": "Turn data into gold!"},
    "cs": {"full_form": "Cybersecurity", "message": "Protect the digital realm like a pro!"},
    "cc": {"full_form": "Cloud Computing", "message": "Soar above the clouds with your tech prowess!"},
    "iot": {"full_form": "Internet of Things", "message": "Connect the world, one device at a time!"},
    "A_H": {"full_form": "Arts and Humanities", "message": "Your creativity will shape culture and inspire others!"},
    "B_C": {"full_form": "Business and Commerce", "message": "You’re destined to lead in the world of trade and innovation!"},
    "S_S": {"full_form": "Social Sciences", "message": "Understanding society is your strength—change the world with your insights!"},
    "E_T": {"full_form": "Education and Teaching", "message": "Empower the next generation with your passion for teaching!"},
    "S_F": {"full_form": "Sports and Fitness", "message": "Your energy will drive success in sports and wellness!"},
    "F_D": {"full_form": "Fashion and Design", "message": "Style is your superpower—create trends that captivate the world!"},
    "L_T": {"full_form": "Literature & Journalism", "message": "Your words will inform, entertain, and inspire the world!"},
    "P": {"full_form": "Psychology", "message": "You’ll unlock the secrets of the mind and help others thrive!"},
    "Law": {"full_form": "Law", "message": "Justice is your calling—shape the world with your legal expertise!"},
    "H_A": {"full_form": "History & Archaeology", "message": "You’ll uncover the past to enlighten the future!"},
    "Philosophy": {"full_form": "Philosophy", "message": "Your deep thoughts will challenge and redefine perspectives!"},
    "Manag": {"full_form": "Management", "message": "You’re a natural leader ready to guide teams to success!"},
    "F_A": {"full_form": "Finance & Accounting", "message": "You’ll master the art of numbers and financial strategy!"},
    "E": {"full_form": "Entrepreneurship", "message": "You’ll build innovative ventures from the ground up!"},
    "MKT": {"full_form": "Marketing", "message": "You’ll captivate audiences with your creative campaigns!"},
    "S_R": {"full_form": "Sales & Retail Management", "message": "Your charisma will drive sales and customer loyalty!"},
    "Teaching": {"full_form": "Teaching", "message": "You’ll inspire and shape the minds of tomorrow!"},
    "SE": {"full_form": "Adaptive Education Teacher", "message": "You’ll empower unique learners to reach their potential!"},
    "Educational_C": {"full_form": "Educational Counseling", "message": "You’ll guide students toward their brightest futures!"},
    "Sports_Management": {"full_form": "Sports Management", "message": "You’ll lead the business of sports to new heights!"},
    "Fitness_Training": {"full_form": "Fitness Training", "message": "You’ll transform lives through health and fitness!"},
    "Coaching": {"full_form": "Coaching", "message": "You’ll motivate athletes to achieve greatness!"},
    "Fashion_Designing": {"full_form": "Fashion Designing", "message": "You’ll set trends with your stunning designs!"},
    "Interior_Design": {"full_form": "Interior Design", "message": "You’ll create beautiful and functional spaces!"},
    "Graphic_Design": {"full_form": "Graphic Design", "message": "Your visual creativity will captivate audiences!"},
    "Social_Work": {"full_form": "Social Work", "message": "You’ll uplift lives and strengthen communities!"},
    "Public_Administration": {"full_form": "Public Administration", "message": "You’ll shape policies for the greater good!"},
    "Community_Development": {"full_form": "Community Development", "message": "You’ll build thriving, connected communities!"}
}

@app.route('/', methods=['GET', 'POST'])
def quiz():
    print(f"Current session state: {session}")
    if 'phase' not in session:
        session['phase'] = 1
        session['questions'] = random.sample(questions, len(questions))
        session['current_question'] = 0
        session['tech_count'] = 0
        session['non_tech_count'] = 0
        print("\n--- Phase 1 Initialized ---")
        print(f"Initial session: {session}")

    if request.method == 'POST':
        choice = request.form.get('choice')
        print(f"POST request received - User choice: {choice}")

        if session['phase'] == 1:
            print(f"Processing Phase 1 - Current question: {session['current_question'] + 1}")
            if choice == 'tech':
                session['tech_count'] += 1
                print("Incremented tech_count")
            elif choice == 'non-tech':
                session['non_tech_count'] += 1
                print("Incremented non_tech_count")
            else:
                print(f"Unexpected choice received: {choice}")
            print(f"Phase 1 Counts -> Tech: {session['tech_count']}, Non-Tech: {session['non_tech_count']}")
            session['current_question'] += 1
            session.modified = True
            print(f"Updated session after choice: {session}")

        elif session['phase'] == 2:
            total_questions = session.get('phase_2_total_questions', 7)
            print(f"Processing Phase 2 - Current question: {session['current_question'] + 1}/{total_questions}")
            current_q = session['questions'][session['current_question']]

            if 'is_tech' in session and session['is_tech']:
                if session['current_question'] < 7:
                    if choice in session['category_counts']:
                        session['category_counts'][choice] += 1
                    print(f"Phase 2 Tech Category Counts -> {session['category_counts']}")
                    session['current_question'] += 1

                elif session['current_question'] == 7:
                    if choice in session['category_counts']:
                        session['highest_category'] = choice
                        session['phase'] = 3
                        session['current_question'] = 0
                        print(f"Phase 2 Tech Category Counts before tiebreaker -> {session['category_counts']}")
                        print(f"8th question answer: {choice}, proceeding directly to Phase 3")
                        print(f"\n--- Phase 3 Started (Highest Category: {choice}) ---")

                        session['aiml_ds_counts'] = {"aiml": 0, "ds": 0}
                        session['industry_counts'] = {"I": 0, "R": 0, "M": 0}
                        session['web_counts'] = {"FD": 0, "DB": 0}
                        session['design_counts'] = {"AM": 0, "PM": 0, "CNC": 0, "WT": 0}
                        if choice == "cloud":
                            session['aiml_ds_counts'] = {"cs": 0, "cc": 0}

                        category_questions = {
                            "ai": load_questions_from_excel("ai.xlsx", 3),
                            "iot": load_questions_from_excel("iot.xlsx", 2),
                            "cloud": load_questions_from_excel("cloud.xlsx", 3),
                            "industry": load_questions_from_excel("industry.xlsx", 4),
                            "design": load_questions_from_excel("design.xlsx", 5),
                            "web": load_questions_from_excel("web.xlsx", 3)
                        }
                        session['questions'] = category_questions.get(choice, [])
                        print(f"Loaded {len(session['questions'])} questions for {choice} in Phase 3")
                        return redirect('/')

                if session['current_question'] == 7 and 'highest_category' not in session:
                    counts = session['category_counts']
                    max_count = max(counts.values())
                    tied_categories = [cat for cat, count in counts.items() if count == max_count]
                    print(f"Phase 2 Tech Category Counts after 7 questions -> {counts}")
                    print(f"Max count: {max_count}, Tied categories: {tied_categories}")

                    if len(tied_categories) > 1:
                        extra_questions = load_questions_from_excel("technical_1.xlsx", 1)
                        session['questions'].extend(extra_questions)
                        session['phase_2_total_questions'] = 8
                        print(f"Added 1 extra question due to tie, new total: {len(session['questions'])}")
                        return redirect('/')
                    else:
                        highest_category = max(counts, key=counts.get)
                        session['highest_category'] = highest_category
                        session['phase'] = 3
                        session['current_question'] = 0
                        print(f"\n--- Phase 3 Started (Highest Category: {highest_category}) ---")

                        session['aiml_ds_counts'] = {"aiml": 0, "ds": 0}
                        session['industry_counts'] = {"I": 0, "R": 0, "M": 0}
                        session['web_counts'] = {"FD": 0, "DB": 0}
                        session['design_counts'] = {"AM": 0, "PM": 0, "CNC": 0, "WT": 0}
                        if highest_category == "cloud":
                            session['aiml_ds_counts'] = {"cs": 0, "cc": 0}

                        category_questions = {
                            "ai": load_questions_from_excel("ai.xlsx", 3),
                            "iot": load_questions_from_excel("iot.xlsx", 2),
                            "cloud": load_questions_from_excel("cloud.xlsx", 3),
                            "industry": load_questions_from_excel("industry.xlsx", 4),
                            "design": load_questions_from_excel("design.xlsx", 5),
                            "web": load_questions_from_excel("web.xlsx", 3)
                        }
                        session['questions'] = category_questions.get(highest_category, [])
                        print(f"Loaded {len(session['questions'])} questions for {highest_category} in Phase 3")
                        return redirect('/')

            else:  # Non-technical path
                if session['current_question'] < 7:
                    if choice in session['category_counts']:
                        session['category_counts'][choice] += 1
                    print(f"Phase 2 Non-Tech Category Counts -> {session['category_counts']}")
                    session['current_question'] += 1

                elif session['current_question'] == 7:
                    if choice in session['category_counts']:
                        session['highest_category'] = choice
                        if choice == 'A_H':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("arts.xlsx", 3)
                            session['category_counts'] = {"L_T": 0, "P": 0, "Law": 0, "H_A": 0, "Philosophy": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Arts and Humanities Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from arts.xlsx")
                            return redirect('/')
                        elif choice == 'B_C':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("business.xlsx", 3)
                            session['category_counts'] = {"Manag": 0, "F_A": 0, "E": 0, "MKT": 0, "S_R": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Business and Commerce Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from business.xlsx")
                            return redirect('/')
                        elif choice == 'E_T':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("teaching.xlsx", 3)
                            session['category_counts'] = {"Teaching": 0, "SE": 0, "Educational_C": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Education and Teaching Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from teaching.xlsx")
                            return redirect('/')
                        elif choice == 'S_F':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("sports.xlsx", 3)
                            session['category_counts'] = {"Sports_Management": 0, "Fitness_Training": 0, "Coaching": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Sports and Fitness Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from sports.xlsx")
                            return redirect('/')
                        elif choice == 'F_D':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("fashion.xlsx", 3)
                            session['category_counts'] = {"Fashion_Designing": 0, "Interior_Design": 0, "Graphic_Design": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Fashion and Design Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from fashion.xlsx")
                            return redirect('/')
                        elif choice == 'S_S':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("services.xlsx", 3)
                            session['category_counts'] = {"Social_Work": 0, "Public_Administration": 0, "Community_Development": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Social Sciences Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from services.xlsx")
                            return redirect('/')
                        else:
                            message = f"You are most suited for {result_messages[choice]['full_form']}! {result_messages[choice]['message']}"
                            print(f"Phase 2 Non-Tech Tiebreaker - 8th question answer: {choice}")
                            print(f"\n--- Phase 2 Completed (Non-Tech Result: {choice}) ---")
                            return render_template("result.html", message=message)

                if session['current_question'] == 7 and 'highest_category' not in session:
                    counts = session['category_counts']
                    max_count = max(counts.values())
                    tied_categories = [cat for cat, count in counts.items() if count == max_count]
                    print(f"Phase 2 Non-Tech Category Counts after 7 questions -> {counts}")
                    print(f"Max count: {max_count}, Tied categories: {tied_categories}")

                    if len(tied_categories) > 1:
                        extra_questions = load_questions_from_excel("non_tech.xlsx", 1)
                        session['questions'].extend(extra_questions)
                        session['phase_2_total_questions'] = 8
                        print(f"Added 1 extra question due to tie, new total: {len(session['questions'])}")
                        return redirect('/')
                    else:
                        highest_category = max(counts, key=counts.get)
                        session['highest_category'] = highest_category
                        if highest_category == 'A_H':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("arts.xlsx", 3)
                            session['category_counts'] = {"L_T": 0, "P": 0, "Law": 0, "H_A": 0, "Philosophy": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Arts and Humanities Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from arts.xlsx")
                            return redirect('/')
                        elif highest_category == 'B_C':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("business.xlsx", 3)
                            session['category_counts'] = {"Manag": 0, "F_A": 0, "E": 0, "MKT": 0, "S_R": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Business and Commerce Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from business.xlsx")
                            return redirect('/')
                        elif highest_category == 'E_T':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("teaching.xlsx", 3)
                            session['category_counts'] = {"Teaching": 0, "SE": 0, "Educational_C": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Education and Teaching Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from teaching.xlsx")
                            return redirect('/')
                        elif highest_category == 'S_F':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("sports.xlsx", 3)
                            session['category_counts'] = {"Sports_Management": 0, "Fitness_Training": 0, "Coaching": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Sports and Fitness Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from sports.xlsx")
                            return redirect('/')
                        elif highest_category == 'F_D':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("fashion.xlsx", 3)
                            session['category_counts'] = {"Fashion_Designing": 0, "Interior_Design": 0, "Graphic_Design": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Fashion and Design Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from fashion.xlsx")
                            return redirect('/')
                        elif highest_category == 'S_S':
                            session['phase'] = 3
                            session['current_question'] = 0
                            session['questions'] = load_questions_from_excel("services.xlsx", 3)
                            session['category_counts'] = {"Social_Work": 0, "Public_Administration": 0, "Community_Development": 0}
                            session['initial_phase_3_questions'] = 3
                            print(f"\n--- Phase 3 Started (Social Sciences Subcategories) ---")
                            print(f"Loaded {len(session['questions'])} questions from services.xlsx")
                            return redirect('/')
                        else:
                            message = f"You are most suited for {result_messages[highest_category]['full_form']}! {result_messages[highest_category]['message']}"
                            print(f"\n--- Phase 2 Completed (Non-Tech Result: {highest_category}) ---")
                            return render_template("result.html", message=message)

            session.modified = True

        elif session['phase'] == 3:
            highest_category = session.get('highest_category')
            total_questions = len(session['questions'])
            current_q = session['questions'][session['current_question']]
            print(f"Processing Phase 3 - Current question: {session['current_question'] + 1}/{total_questions}")

            # Only increment counts if the choice matches the current category's subcategories
            if highest_category == "A_H" and choice in ["L_T", "P", "Law", "H_A", "Philosophy"]:
                session['category_counts'][choice] += 1
                print(f"Phase 3 Arts Counts -> {session['category_counts']}")
            elif highest_category == "B_C" and choice in ["Manag", "F_A", "E", "MKT", "S_R"]:
                session['category_counts'][choice] += 1
                print(f"Phase 3 Business Counts -> {session['category_counts']}")
            elif highest_category == "E_T" and choice in ["Teaching", "SE", "Educational_C"]:
                session['category_counts'][choice] += 1
                print(f"Phase 3 Education Counts -> {session['category_counts']}")
            elif highest_category == "S_F" and choice in ["Sports_Management", "Fitness_Training", "Coaching"]:
                session['category_counts'][choice] += 1
                print(f"Phase 3 Sports Counts -> {session['category_counts']}")
            elif highest_category == "F_D" and choice in ["Fashion_Designing", "Interior_Design", "Graphic_Design"]:
                session['category_counts'][choice] += 1
                print(f"Phase 3 Fashion Counts -> {session['category_counts']}")
            elif highest_category == "S_S" and choice in ["Social_Work", "Public_Administration", "Community_Development"]:
                session['category_counts'][choice] += 1
                print(f"Phase 3 Social Sciences Counts -> {session['category_counts']}")
            elif highest_category == "industry" and choice in ["I", "R", "M"]:
                session['industry_counts'][choice] += 1
            elif highest_category == "web" and choice in ["FD", "DB"]:
                session['web_counts'][choice] += 1
            elif highest_category == "design" and choice in ["AM", "PM", "CNC", "WT"]:
                session['design_counts'][choice] += 1
            elif highest_category in ["ai", "iot"] and choice in ["aiml", "ds"]:
                session['aiml_ds_counts'][choice] += 1
            elif highest_category == "cloud" and choice in ["cc", "cs"]:
                session['aiml_ds_counts'][choice] += 1
                print(f"Phase 3 Cloud Counts -> {session['aiml_ds_counts']}")

            print(f"User selected choice: {choice} (Question {session['current_question'] + 1})")
            session['current_question'] += 1
            print(f"Moving to next question: {session['current_question'] + 1} of {total_questions}")
            session.modified = True

    if session['phase'] == 1:
        print(f"Rendering Phase 1 - Current question: {session['current_question'] + 1}/{len(session['questions'])}")
        if session['current_question'] < len(session['questions']):
            question = session['questions'][session['current_question']]
            print(f"Displaying question: {question['question']}")
            return render_template("quiz.html", question=question, phase=session['phase'])
        else:
            print(f"End of Phase 1 - Tech Count: {session['tech_count']}, Non-Tech Count: {session['non_tech_count']}")
            session['phase'] = 2
            session['current_question'] = 0
            if session['tech_count'] > session['non_tech_count']:
                print("Tech count is higher - Loading technical questions")
                session['questions'] = load_questions_from_excel("technical_1.xlsx", 7)
                session['category_counts'] = {"ai": 0, "iot": 0, "cloud": 0, "industry": 0, "design": 0, "web": 0}
                session['is_tech'] = True
                print("\n--- Phase 2 Started (Technical - tech_count higher) ---")
            else:
                print("Non-tech count is higher or equal - Loading non-technical questions")
                session['questions'] = load_questions_from_excel("non_tech.xlsx", 7)
                session['category_counts'] = {"A_H": 0, "B_C": 0, "S_S": 0, "E_T": 0, "S_F": 0, "F_D": 0}
                session['is_tech'] = False
                print("\n--- Phase 2 Started (Non-Technical - non_tech_count higher or equal) ---")

            session['phase_2_total_questions'] = 7
            session.modified = True
            print(f"Session updated for Phase 2: {session}")
            return redirect('/')

    elif session['phase'] == 2:
        total_questions = session.get('phase_2_total_questions', 7)
        print(f"Rendering Phase 2 - Current question: {session['current_question'] + 1}/{total_questions}")
        if session['current_question'] < total_questions:
            question = session['questions'][session['current_question']]
            print(f"Displaying question: {question['question']}")
            return render_template("quiz.html", question=question, phase=session['phase'])
        else:
            if 'is_tech' in session and session['is_tech']:
                return redirect('/')
            else:  # Non-technical path
                counts = session['category_counts']
                max_count = max(counts.values())
                tied_categories = [cat for cat, count in counts.items() if count == max_count]
                print(f"Phase 2 Non-Tech Category Counts -> {counts}")
                print(f"Max count: {max_count}, Tied categories: {tied_categories}")

                highest_category = session.get('highest_category', max(counts, key=counts.get))
                if highest_category == 'A_H':
                    session['phase'] = 3
                    session['current_question'] = 0
                    session['questions'] = load_questions_from_excel("arts.xlsx", 3)
                    session['category_counts'] = {"L_T": 0, "P": 0, "Law": 0, "H_A": 0, "Philosophy": 0}
                    session['initial_phase_3_questions'] = 3
                    print(f"\n--- Phase 3 Started (Arts and Humanities Subcategories) ---")
                    print(f"Loaded {len(session['questions'])} questions from arts.xlsx")
                    session.modified = True
                    return redirect('/')
                elif highest_category == 'B_C':
                    session['phase'] = 3
                    session['current_question'] = 0
                    session['questions'] = load_questions_from_excel("business.xlsx", 3)
                    session['category_counts'] = {"Manag": 0, "F_A": 0, "E": 0, "MKT": 0, "S_R": 0}
                    session['initial_phase_3_questions'] = 3
                    print(f"\n--- Phase 3 Started (Business and Commerce Subcategories) ---")
                    print(f"Loaded {len(session['questions'])} questions from business.xlsx")
                    session.modified = True
                    return redirect('/')
                elif highest_category == 'E_T':
                    session['phase'] = 3
                    session['current_question'] = 0
                    session['questions'] = load_questions_from_excel("teaching.xlsx", 3)
                    session['category_counts'] = {"Teaching": 0, "SE": 0, "Educational_C": 0}
                    session['initial_phase_3_questions'] = 3
                    print(f"\n--- Phase 3 Started (Education and Teaching Subcategories) ---")
                    print(f"Loaded {len(session['questions'])} questions from teaching.xlsx")
                    session.modified = True
                    return redirect('/')
                elif highest_category == 'S_F':
                    session['phase'] = 3
                    session['current_question'] = 0
                    session['questions'] = load_questions_from_excel("sports.xlsx", 3)
                    session['category_counts'] = {"Sports_Management": 0, "Fitness_Training": 0, "Coaching": 0}
                    session['initial_phase_3_questions'] = 3
                    print(f"\n--- Phase 3 Started (Sports and Fitness Subcategories) ---")
                    print(f"Loaded {len(session['questions'])} questions from sports.xlsx")
                    session.modified = True
                    return redirect('/')
                elif highest_category == 'F_D':
                    session['phase'] = 3
                    session['current_question'] = 0
                    session['questions'] = load_questions_from_excel("fashion.xlsx", 3)
                    session['category_counts'] = {"Fashion_Designing": 0, "Interior_Design": 0, "Graphic_Design": 0}
                    session['initial_phase_3_questions'] = 3
                    print(f"\n--- Phase 3 Started (Fashion and Design Subcategories) ---")
                    print(f"Loaded {len(session['questions'])} questions from fashion.xlsx")
                    session.modified = True
                    return redirect('/')
                elif highest_category == 'S_S':
                    session['phase'] = 3
                    session['current_question'] = 0
                    session['questions'] = load_questions_from_excel("services.xlsx", 3)
                    session['category_counts'] = {"Social_Work": 0, "Public_Administration": 0, "Community_Development": 0}
                    session['initial_phase_3_questions'] = 3
                    print(f"\n--- Phase 3 Started (Social Sciences Subcategories) ---")
                    print(f"Loaded {len(session['questions'])} questions from services.xlsx")
                    session.modified = True
                    return redirect('/')
                else:
                    message = f"You are most suited for {result_messages[highest_category]['full_form']}! {result_messages[highest_category]['message']}"
                    print(f"\n--- Phase 2 Completed (Non-Tech Result: {highest_category}) ---")
                    return render_template("result.html", message=message)

    elif session['phase'] == 3:
        total_questions = len(session['questions'])
        print(f"Rendering Phase 3 - Current question: {session['current_question'] + 1}/{total_questions}")
        if session['current_question'] < total_questions:
            question = session['questions'][session['current_question']]
            print(f"Displaying question: {question['question']}")
            return render_template("quiz.html", question=question, phase=session['phase'])
        else:
            highest_category = session.get('highest_category')
            print(f"Phase 3 completed - Highest category: {highest_category}")
            if highest_category == "iot":
                result = result_messages["iot"]
                message = f"You are most suited for {result['full_form']}! {result['message']}"
                print("\n--- Phase 3 Completed (Highest Subcategory: iot) ---")
                return render_template("result.html", message=message)
            elif highest_category in ["A_H", "B_C", "E_T", "S_F", "F_D", "S_S"]:
                initial_questions = session.get('initial_phase_3_questions', 3)
                if session['current_question'] == initial_questions:
                    counts = session['category_counts']
                    max_count = max(counts.values())
                    tied_categories = [cat for cat, count in counts.items() if count == max_count]
                    category_type = {
                        "A_H": "Arts",
                        "B_C": "Business",
                        "E_T": "Education",
                        "S_F": "Sports",
                        "F_D": "Fashion",
                        "S_S": "Social Sciences"
                    }[highest_category]
                    print(f"Phase 3 {category_type} Counts after initial questions -> {counts}")
                    print(f"Max count: {max_count}, Tied categories: {tied_categories}")

                    if len(tied_categories) > 1:
                        file_map = {
                            "A_H": "arts.xlsx",
                            "B_C": "business.xlsx",
                            "E_T": "teaching.xlsx",
                            "S_F": "sports.xlsx",
                            "F_D": "fashion.xlsx",
                            "S_S": "services.xlsx"
                        }
                        # Load one more question from the same file, excluding previously asked questions
                        extra_questions = load_questions_from_excel(file_map[highest_category], 1, exclude_questions=session['questions'])
                        if not extra_questions:  # If no new questions available, reuse but log it
                            print(f"No new questions available in {file_map[highest_category]}, reusing a random one")
                            extra_questions = random.sample(session['questions'], 1)
                        session['questions'].extend(extra_questions)
                        print(f"Added 1 extra question due to tie from {file_map[highest_category]}, new total: {len(session['questions'])}")
                        session.modified = True
                        return redirect('/')
                    else:
                        highest_subcategory = max(counts, key=counts.get)
                        result = result_messages.get(highest_subcategory, {"full_form": highest_subcategory.replace('_', ' ').title(),
                                                                          "message": "Your skills will shape the future!"})
                        message = f"You are most suited for {result['full_form']}! {result['message']}"
                        print(f"\n--- Phase 3 Completed ({category_type} Subcategory: {highest_subcategory}) ---")
                        return render_template("result.html", message=message)
                else:  # After tiebreaker question
                    last_q = session['questions'][session['current_question'] - 1]
                    highest_subcategory = None
                    for i, disc in enumerate(last_q['options_disc']):
                        if disc == choice:
                            highest_subcategory = disc
                            break
                    if highest_subcategory is None:
                        highest_subcategory = max(session['category_counts'], key=session['category_counts'].get)
                    result = result_messages.get(highest_subcategory, {"full_form": highest_subcategory.replace('_', ' ').title(),
                                                                      "message": "Your skills will shape the future!"})
                    category_type = {
                        "A_H": "Arts",
                        "B_C": "Business",
                        "E_T": "Education",
                        "S_F": "Sports",
                        "F_D": "Fashion",
                        "S_S": "Social Sciences"
                    }[highest_category]
                    message = f"You are most suited for {result['full_form']}! {result['message']}"
                    print(f"\n--- Phase 3 Completed ({category_type} Subcategory after tiebreaker: {highest_subcategory}) ---")
                    return render_template("result.html", message=message)
            else:
                if highest_category == "industry":
                    highest_subcategory = max(session['industry_counts'], key=session['industry_counts'].get)
                elif highest_category == "web":
                    highest_subcategory = max(session['web_counts'], key=session['web_counts'].get)
                elif highest_category == "design":
                    highest_subcategory = max(session['design_counts'], key=session['design_counts'].get)
                elif highest_category == "cloud":
                    cloud_counts = {k: session['aiml_ds_counts'][k] for k in ['cc', 'cs']}
                    highest_subcategory = max(cloud_counts, key=cloud_counts.get)
                    print(f"Cloud-specific counts: {cloud_counts}")
                else:
                    highest_subcategory = max(session['aiml_ds_counts'], key=session['aiml_ds_counts'].get)

                result = result_messages.get(highest_subcategory, {"full_form": highest_subcategory.upper(),
                                                                   "message": "Great choice! You're on your way to an exciting tech career!"})
                message = f"You are most suited for {result['full_form']}! {result['message']}"
                print(f"\n--- Phase 3 Completed (Highest Subcategory: {highest_subcategory}) ---")
                return render_template("result.html", message=message)

if __name__ == '__main__':
    app.run(debug=True)