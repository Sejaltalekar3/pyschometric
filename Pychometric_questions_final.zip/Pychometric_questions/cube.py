import pandas as pd
import random

# Load the xlsx file
df = pd.read_excel('data.xlsx')

# Print unique categories to debug
print(df['category'].unique())

# Filter data based on the given conditions
categories = ['tech_non', 'problem-solving', 'subject-related', 'Hobbies', 'Career ']
filtered_df = df[df['category'].isin(categories)]  # Filter based on category

# Separate the 'tech_non' category
tech_non_df = filtered_df[filtered_df['category'] == 'tech_non']

# Print 3 random questions from 'tech_non' category
print("Random Tech-Non Questions:")
tech_non_questions = tech_non_df.sample(n=3, random_state=42)
for index, row in tech_non_questions.iterrows():
    question = row['question']
    options = [row[col] for col in [1, 2, 3, 4, 5, 6, 7] if pd.notnull(row[col])]
    print(f"Question: {question}")
    print(f"Options: {', '.join(map(str, options))}")
    print("-" * 50)

# Define the other categories
other_categories = ['problem-solving', 'subject-related', 'Hobbies', 'Career ']

# Print 1 random question from each of the other categories
print("Random Questions from Other Categories:")
for category in other_categories:
    category_df = filtered_df[filtered_df['category'] == category]

    # Check if the category has at least one question
    if not category_df.empty:
        random_question = category_df.sample(n=1, random_state=42)

        for index, row in random_question.iterrows():
            question = row['question']
            options = [row[col] for col in [1, 2, 3, 4, 5, 6, 7] if pd.notnull(row[col])]
            print(f"Category: {category}")
            print(f"Question: {question}")
            print(f"Options: {', '.join(map(str, options))}")
            print("-" * 50)
    else:
        print(f"No questions available for category: {category}")
        print("-" * 50)

# Check if 'technical' category exists before sampling
print("Random Technical Questions (if category is 'technical'):")
# Strip any leading or trailing spaces from the category names
df['category'] = df['category'].str.strip()

technical_questions = df[df['category'] == 'technical']

# Check if there are any technical questions available
if not technical_questions.empty:
    random_technical_questions = technical_questions.sample(n=3, random_state=42)

    for index, row in random_technical_questions.iterrows():
        question = row['question']
        print(f"Question: {question}")
else:
    print("No questions available for category: 'technical'")