selected_options = ['tech', 'tech', 'tech', 'tech', 'non-tech', 'non-tech', 'non-tech']

tech_count = 0
non_tech_count = 0

# Iterate over selected options and count tech/non-tech
for option in selected_options:
    if option:  # Check if option is not None or empty
        cleaned_option = option.strip().lower()  # Clean the option string

        if cleaned_option == "tech":
            tech_count += 1
        elif cleaned_option == "non-tech":
            non_tech_count += 1

print(f"Selected Options: {selected_options}")
print(f"Tech Count: {tech_count}")
print(f"Non-Tech Count: {non_tech_count}")
